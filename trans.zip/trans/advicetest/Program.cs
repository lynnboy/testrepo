﻿// See https://aka.ms/new-console-template for more information
using OpenAI;
using OpenAI.Chat;
using System.ClientModel;
using System.ClientModel.Primitives;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;

string API_ENDPOINT = "http://47.113.144.240:11434/v1";
string API_KEY = "EMPTY";
string MODEL = "deepseek-r1:7b";
API_ENDPOINT = "http://47.113.144.240/v1";
MODEL = "qwen2.5:latest";
//MODEL = "qwen3:4b";
API_ENDPOINT = "https://api.deepseek.com";
API_KEY = "sk-020cf3e0ef8a43068b81a21ba8beddd3";
MODEL = "deepseek-chat";

string prompt = """
You are a MermaidJS expert. Generate a valid, syntactically correct MermaidJS diagram based on the description I provide. Follow these guidelines:

Respond ONLY with the MermaidJS code, without any introduction, explanation, or conclusion. Do not use backticks or any other formatting other than starting the response with three backticks and mermaidjs suitable for using in markdown, then begin your response with the diagram type declaration and end it with the last line of MermaidJS code and closing backticks.
""";

prompt = """
""";

OpenAIClient openaiclient = new OpenAIClient(new ApiKeyCredential(API_KEY),
    new OpenAIClientOptions
    {
        Endpoint = new Uri(API_ENDPOINT),
        Transport = new HttpClientPipelineTransport(new HttpClient(new HttpClientHandler
        {
            UseProxy = false,
        }))
    });
var client = openaiclient.GetChatClient(MODEL);

var lines = """
    a
    """;

lines = """
    b
    """;

await CreateGraph(prompt, client, lines);

string LookupModel()
{
    return "";
}

ChatTool lookupModelsTool = ChatTool.CreateFunctionTool(nameof(LookupModel),
    "lookup camera models by a set of parameters.",
    BinaryData.FromString("""
        {   "type": "object",
            "properties": {
                ""
            },
        }
        """)
    );

static async Task CreateGraph(string prompt, ChatClient client, string lines)
{
    var time = DateTime.Now;
    var messages = new ChatMessage[]
    {
        ChatMessage.CreateSystemMessage(prompt),
        ChatMessage.CreateUserMessage(lines),
    };
    var options = new ChatCompletionOptions
    {
        Temperature = 0.0f,
        Tools =
        {

        },
    };
    var res = await client.CompleteChatAsync(messages, options);
    var output = res.Value.Content[0].Text;

    Console.WriteLine(output);

    var list = output.Split('\n');

    if (list.FirstOrDefault().ToLower() == "<think>")
    {
        list = list.SkipWhile(r => r.ToLower() != "</think>").Skip(1).ToArray();
    }
    list = list.Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();

    //Console.WriteLine(string.Join("\n", list));

    Console.WriteLine("时间：" + (DateTime.Now - time));
}
