﻿// See https://aka.ms/new-console-template for more information
using OpenAI;
using OpenAI.Chat;
using System.ClientModel;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;

string API_ENDPOINT = "http://47.113.144.240:11434/v1";
string API_KEY = "EMPTY";
string MODEL = "deepseek-r1:7b";
API_ENDPOINT = "http://47.113.144.240/v1";
MODEL = "qwen2.5:latest";
//MODEL = "qwen3:4b";
//API_ENDPOINT = "https://api.deepseek.com";
//API_KEY = "sk-020cf3e0ef8a43068b81a21ba8beddd3";
//MODEL = "deepseek-chat";

string prompt = """
/no_think
You are a MermaidJS expert. Generate a valid, syntactically correct MermaidJS diagram based on the description I provide. Follow these guidelines:

1. Use the appropriate diagram type (flowchart, sequence, class, etc.) based on the context.
2. Ensure all syntax is correct and up-to-date with the latest MermaidJS version.
3. Use clear, concise node and relationship labels.
4. Implement appropriate styling and colors to enhance readability.
5. Include a title using the graph TB syntax for top-to-bottom diagrams or graph LR for left-to-right.
6. Add comments to explain complex parts of the diagram.
7. Optimise the layout for clarity and minimal crossing lines.
8. Use British English spelling for all text elements (labels, titles, etc.).

Respond ONLY with the MermaidJS code, without any introduction, explanation, or conclusion. Do not use backticks or any other formatting other than starting the response with three backticks and mermaidjs suitable for using in markdown, then begin your response with the diagram type declaration and end it with the last line of MermaidJS code and closing backticks.
""";

prompt = """
/no_think
你是 MermaidJS 专家。基于我提供的描述生成有效的，语法正确的 MermaidJS 图。遵循以下指导：

1. 基于上下文，使用适当的图类型（流程图、序列图、类图等等）。
2. 确保语法完全正确且与最新的 MermaidJS 版本保持一致。
3. 使用清晰简明的节点和关系标签。
4. 采用恰当的绘制风格和颜色以增强可读性。
5. 为自上而下的图添加 graph TB 语法的标题，为自左向右的图添加 graph LR 语法的标题。
6. 添加注释对图中的复杂部分进行解释。
7. 优化布局，使其清晰，并尽量减少交叉的线。
8. 为文本元素（标签、标题等）使用*中文*。
9. 文本元素使用引号括起来，以避免文本中的特殊字符引起语法错误。

结果中仅包含 MermaidJS 代码，不能包含介绍、解释或结论等说明文字。不要使用反引号 ` 或其他任何格式化标记。
""";

OpenAIClient openaiclient = new OpenAIClient(new ApiKeyCredential(API_KEY), new OpenAIClientOptions { Endpoint = new Uri(API_ENDPOINT) });
var client = openaiclient.GetChatClient(MODEL);

var lines = """
创建 mermaid depicting a workflow where a developer is uplifting an application from AngularJS to ReactJS leveraging AI tooling such as IDE Github Copilot, Interactive CLI AI tooling such as Aider powered by LLMs via an API.

Written text should be in *中文* for labels, The diagram should be informal in nature suitable for excalidraw in standard mermaidjs format.
""";

lines = """
    绘制一个流程图，描述简单的表达式求值器的工作原理。表达式支持加法和乘法运算，操作数为整数。
    """;

await CreateGraph(prompt, client, lines);

static async Task CreateGraph(string prompt, ChatClient client, string lines)
{
    var time = DateTime.Now;
    var res = await client.CompleteChatAsync(new ChatMessage[]
    {
        ChatMessage.CreateSystemMessage(prompt),
        ChatMessage.CreateUserMessage(lines),
    }, new ChatCompletionOptions { Temperature = 0.0f });
    var output = res.Value.Content[0].Text;

    Console.WriteLine(output);

    var list = output.Split('\n');

    if (list.FirstOrDefault().ToLower() == "<think>")
    {
        list = list.SkipWhile(r => r.ToLower() != "</think>").Skip(1).ToArray();
    }
    list = list.Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();

    //Console.WriteLine(string.Join("\n", list));

    Console.WriteLine("时间：" + (DateTime.Now - time));
}
