﻿// See https://aka.ms/new-console-template for more information
using OpenAI;
using System.ClientModel;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;

string API_ENDPOINT = "http://47.113.144.240/v1";
string API_KEY = "EMPTY";
string MODEL = "deepseek-r1:7b";
MODEL = "qwen2.5:latest";
//MODEL = "qwen3:latest";
MODEL = "qwen3:4b";

//API_ENDPOINT = "http://10.11.224.211:11434/v1";
//MODEL = "qwen2.5:latest";

//API_ENDPOINT = "https://api.deepseek.com";
//API_KEY = "sk-020cf3e0ef8a43068b81a21ba8beddd3";
//MODEL = "deepseek-chat";

string prompt = """
/no_think
你是翻译。
请遵守以下规则进行翻译工作：
<instruction>
- 每一行之间没有关联，请单独完成每一行的翻译工作。
- 对于输入的每一行文字，识别并排除开头的序号，将内容翻译成中文、英文和日文三种语言。
- 对于每一行文字输入，分别依次给出中文、英文、日文的三行文字输出，输出总行数应当为输入行数的三倍，每行前面带有序号和语言标记。
</instruction>
<sample>
以下[input]标签的内容是输入的多行文本，[output]标签的内容（不包括标签）为对应的输出
[input]
[1] This is the first sentence.

[2] 地震是一种自然灾害。

[3] これは3つ目の言葉です。
[input end]
[output]
[1][中] 这是第一句话。
[1][英] This is the first sentence.
[1][日] これは最初の言葉です。 

[2][中] 地震是一种自然灾害。
[2][英] Earthquake is a natural disaster.
[2][日] 地震は自然災害である。 

[3][中] 这是第三句话。
[3][英] This is the third sentence.
[3][日] これは3つ目の言葉です。
[output end]
</sample>
""";

string prompt_zh = """
/no_think
你是翻译。
请遵守以下规则进行翻译工作：
<instruction>
- 每一行之间没有关联，请单独完成每一行的翻译工作。
- 对于输入的每一行文字，识别并排除开头的序号，将内容翻译成中文。
- 对于每一行文字输入，分别给出中文输出，输出总行数应当等于输入行数，每行前面带有序号和语言标记。
</instruction>
<sample>
以下[input]标签的内容是输入的多行文本，[output]标签的内容（不包括标签）为对应的输出
[input]
[1] This is the first sentence.

[2] 地震是一种自然灾害。

[3] これは3つ目の言葉です。
[input end]
[output]
[1][中] 这是第一句话。

[2][中] 地震是一种自然灾害。

[3][中] 这是第三句话。
[output end]
</sample>
""";

string prompt_en = """
/no_think
你是翻译。
请遵守以下规则进行翻译工作：
<instruction>
- 每一行之间没有关联，请单独完成每一行的翻译工作。
- 对于输入的每一行文字，识别并排除开头的序号，将内容翻译成英文。
- 对于每一行文字输入，分别给出英文输出，输出总行数应当等于输入行数，每行前面带有序号和语言标记。
</instruction>
<sample>
以下[input]标签的内容是输入的多行文本，[output]标签的内容（不包括标签）为对应的输出
[input]
[1] This is the first sentence.

[2] 地震是一种自然灾害。

[3] これは3つ目の言葉です。
[input end]
[output]
[1][英] This is the first sentence.

[2][英] Earthquake is a natural disaster.

[3][英] This is the third sentence.
[output end]
</sample>
""";

string prompt_ja = """
/no_think
你是翻译。
请遵守以下规则进行翻译工作：
<instruction>
- 每一行之间没有关联，请单独完成每一行的翻译工作。
- 对于输入的每一行文字，识别并排除开头的序号，将内容翻译成日文。
- 对于每一行文字输入，分别给出日文输出，输出总行数应当等于输入行数，每行前面带有序号和语言标记。
</instruction>
<sample>
以下[input]标签的内容是输入的多行文本，[output]标签的内容（不包括标签）为对应的输出
[input]
[1] This is the first sentence.

[2] 地震是一种自然灾害。

[3] これは3つ目の言葉です。
[input end]
[output]
[1][日] これは最初の言葉です。 

[2][日] 地震は自然災害である。 

[3][日] これは3つ目の言葉です。
[output end]
</sample>
""";

OpenAIClient openaiclient = new OpenAIClient(new ApiKeyCredential(API_KEY), new OpenAIClientOptions { Endpoint = new Uri(API_ENDPOINT) });
var client = openaiclient.GetChatClient(MODEL);

var lines = """
    [1] When you request a chat completion, the default behavior is for the server to generate it in its entirety before sending it back in a single response.

    [2] Obtains a subview over some consecutive elements of this span, the elements to be included are determined by an element count and an offset. 

    [3] 江苏是民营经济大省，民营企业占全省企业总数的98%左右。

    [4] 据报道，缅甸第二大城市曼德勒西南部发生7.9级强烈地震，震源深度30千米。

    [5] 近日，中国人民解放军东部战区位台岛周边海空域组织海空兵力开展战备警巡和联合演训，检验提升部队打仗能力。
    """;

//lines = """
//    人工知能の大モデルによるガバナンスの課題も無視できない。
//    """;
await Trans(prompt, client, lines);
await Trans(prompt_zh, client, lines);
await Trans(prompt_en, client, lines);
await Trans(prompt_ja, client, lines);

static async Task Trans(string prompt, OpenAI.Chat.ChatClient client, string lines)
{
    var time = DateTime.Now;
    var res = await client.CompleteChatAsync(new OpenAI.Chat.ChatMessage[]
    {
                OpenAI.Chat.ChatMessage.CreateSystemMessage(prompt),
                OpenAI.Chat.ChatMessage.CreateUserMessage(lines),
    }, new OpenAI.Chat.ChatCompletionOptions { Temperature = 0.0f });
    var output = res.Value.Content[0].Text;
    var list = output.Split('\n');

    if (list.FirstOrDefault().ToLower() == "<think>")
    {
        list = list.SkipWhile(r => r.ToLower() != "</think>").Skip(1).ToArray();
    }
    list = list.Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();

    var regex = new Regex(@"^\[(\d)\]\s*\[(中|英|日)\]\s*(.*)$");

    //Console.WriteLine(lines);
    //Console.WriteLine("--^^^^-----vvvvv--");
    Console.WriteLine(string.Join("\n", list));

    Console.WriteLine("时间：" + (DateTime.Now - time));
}

//foreach (var l in output.Split("\n"))
//{
//    var m = regex.Match(l);
//    if (m.Success)
//    {
//        var n = Convert.ToInt32(m.Groups[1].Value);
//        var lang = m.Groups[2].Value;
//        var text = m.Groups[3].Value;
//        Console.WriteLine($"{n}-{lang}\t{text}");
//    }
//}

//foreach (var p in lines.Split("\n").Zip(list))
//{
//    Console.WriteLine("################");
//    Console.WriteLine(p.First);
//    Console.WriteLine(p.Second);
//}
