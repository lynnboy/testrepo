﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Windows.Win32;
using Windows.Win32.Foundation;
using Windows.Win32.UI.Accessibility;
using static Windows.Win32.PInvoke;
using System.Windows.Markup;
using System.Collections.ObjectModel;
using System.Diagnostics;
using OpenAI.Chat;
using OpenAI;
using System.ClientModel;
using System.ComponentModel;
using Microsoft.Win32;
using System.IO;
using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Json.Serialization;
using System.Windows.Automation.Peers;
using System.Text.RegularExpressions;
using System.Collections.Concurrent;
using System.Windows.Interop;

namespace trans
{
    class NoReleaseSafeHandle : SafeHandle
    {
        public NoReleaseSafeHandle(int value)
            : base(IntPtr.Zero, true)
        {
            this.SetHandle(new IntPtr(value));
        }

        public override bool IsInvalid => true;

        protected override bool ReleaseHandle()
        {
            return true;
        }
    }

    public class ObservableList<T> : ObservableCollection<T>
    {
        public ObservableList() { }
        public ObservableList(IEnumerable<T> list) : base(list) { }
        public ObservableList(List<T> list) : base(list) { }
        public List<T> List { get => (List<T>)Items; }
    }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string API_KEY = "sk-020cf3e0ef8a43068b81a21ba8beddd3";
        static string API_ENDPOINT = "https://api.deepseek.com";
        static string MODEL = "deepseek-chat";
        static string PROMPT = "";
        static string PROMPT_EN = "";
        static string PROMPT_ZH = "";
        static string PROMPT_JA = "";
        static int TRANSLATE_BATCH = 10;
        static int TRANSLATE_RT_BATCH = 1;
        static int WORKER_COUNT = 3;
        static bool SEPARATE = false;

        static bool flag;
        static uint eventTime;
        static MainWindow win;
        ChatClient client;
        Timer timer;
        Regex regex = new Regex(@"^\[(\d)\]\s*\[(中|英|日)\]\s*(.*)$");

        static void HandleWinEvent(HWINEVENTHOOK hWinEventHook, uint ev, HWND hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
        {
            if (!flag) return;

            var hr = AccessibleObjectFromEvent(hwnd, (uint)idObject, (uint)idChild, out var pacc, out var varChild);
            //Debug.WriteLine($"Event: {ev} hwnd: {hwnd} idObject: {idObject} idChild: {idChild} dwEventThread: {dwEventThread} dwmsEventTime: {dwmsEventTime}");
            //Debug.WriteLine($"hr {hr}  pacc {pacc is null}  ev {ev}");
            if (ev == EVENT_OBJECT_FOCUS)
                Debug.WriteLine($"hr {hr}  pacc {pacc}  ev {ev}  val {hr == 0 && pacc != null && ev == EVENT_OBJECT_FOCUS}");
            if (hr != 0 || pacc == null || ev != EVENT_OBJECT_FOCUS || eventTime >= dwmsEventTime) return;

            //var parent = pacc.accParent as IAccessible;
            win.EndPointer();
            flag = false;

            //win.lines.Clear();
            //win.Dump(pacc, 0);
            win.FindTarget(pacc);
        }

        public static bool Succeeded(int hr)
        {
            return hr >= 0;
        }

        private void Dump(IAccessible pacc, int nest = 0)
        {
            //try
            {
                if (pacc == null) return;

                DumpData(pacc, nest);
            }
            //catch (Exception e)
            //{
            //    Debug.WriteLine(e);
            //}
        }

        IAccessible targetAccRoot;
        int childcount;

        enum Role { div = 20, text = 41, list = 33, li = 34 }

        class TreePart
        {
            public string text;
            public int nest;
            public Role role;
            public int id;
            public TreePart[] children;
            public IAccessible accObj;
        }
        private TreePart? DumpTree(IAccessible acc, int id, int nest)
        {
            try
            {
                var role = acc.get_accRole(0);
                var text = new string(acc.get_accName(0).AsSpan());
                var dumptree_line = $"{nest}{new string(' ', nest)} {id}, {role}, {text}";
                //Debug.WriteLine($"{nest}{new string(' ', nest)} {id}, {role}, {text}");
#if DUMPTREE
                File.AppendAllLines("dumptree.txt", new[] { dumptree_line });
#endif

                var count = acc.accChildCount;
                //Debug.WriteLine($"nest {nest}, childcount: {count}");
                object[] arry = new object[count + 1];
                TreePart[] children = new TreePart[count];
                if (Succeeded(AccessibleChildren(acc, 0, arry, out var len)))
                {
                    for (int c = 0; c < len; c++)
                    {
                        var child = arry[c];
                        if (arry[c] is IAccessible accCh)
                        {
                            children[c] = DumpTree(accCh, c, nest + 1);
                        }
                        else
                        {
                            //children[c] = new TreePart { id = c, nest = nest + 1, text = new string(acc.get_accName(c).AsSpan()) };
                        }
                    }
                }
                return new TreePart
                {
                    id = id,
                    text = text,
                    nest = nest,
                    role = (Role)(int)role,
                    children = children,
                    accObj = acc,
                };
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"{nest} {id} failed.");
                return null;
            }
        }

        void FindTarget(IAccessible acc)
        {
#if DUMPTREE
            File.AppendAllLines("dumptree.txt", new[] { "!!!!!!!!!! DUMP UI DOM !!!!!!!!!!" });
#endif
            var tree = DumpTree(acc, 0, 0);
            var targettree = FindTarget(tree);
            if (targettree != null)
            {
                lines.Clear();
                //win.Dump(pacc, 0);
                FillMessageOfTree(targettree);

                if (timer != null)
                {
                    timer.Dispose();
                }
                timer = new Timer(this.OnTimer, null, 1000, 1000);

                targetAccRoot = targettree.accObj;
                childcount = targettree.children.Length;
            }
        }

        private void FillMessageOfTree(TreePart targettree)
        {
            var list = new List<SubtitleMessage>();
            foreach (var child in targettree.children)
            {
                if (child.role != Role.list) continue;
                list.Add(TreeToMessage(child, null));
            }
            this.Dispatcher.BeginInvoke(() =>
            {
                messageList = new ObservableList<SubtitleMessage>(list);
                lbMessage.ItemsSource = messageList;
                foreach (var msg in list)
                {
                    if (SEPARATE)
                    {
                        stack_zh.Push(msg);
                        stack_en.Push(msg);
                        stack_ja.Push(msg);
                    }
                    else
                    {
                        stack.Push(msg);
                    }
                }
                lbMessage.ScrollIntoView(messageList[messageList.Count - 1]);
            });
        }

        class SubtitleMessage : INotifyPropertyChanged
        {
            private string? zh, en, ja;
            private bool trans;
            private CancellationTokenSource cts;

            public override string ToString() => $"[{(Translated?1:0)}]{Who}: {Text}";

            public string Who { get; set; }
            public DateTime? Time { get; set; }
            public string Text { get; set; }
            [JsonIgnore]
            public bool Translated { get; set; }
            [JsonIgnore]
            public string TranslateTask { get; set; }
            public string? ZH { get; set; }
            public string? EN { get; set; }
            public string? JA { get; set; }

            [JsonIgnore]
            public string? Text2 { get; set; }

            public event PropertyChangedEventHandler? PropertyChanged;

            internal void SetText2(string text)
            {
                Text2 = text;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Text2"));
            }
            internal void SetText2ByLang(LangID v)
            {
                SetText2(v switch { LangID.ZH => ZH, LangID.EN => EN, LangID.JA => JA, _ => null });
            }

            public void Cancel()
            {
                cts?.Cancel();
            }

            public void MakeCTS(CancellationToken token)
            {
                cts = CancellationTokenSource.CreateLinkedTokenSource(token);
            }
            public CancellationToken GetCancellationToken(CancellationToken token)
            {
                return cts?.Token ?? token;
            }
        }

        ObservableList<SubtitleMessage> messageList = new ObservableList<SubtitleMessage>();

        SubtitleMessage TreeToMessage(TreePart tree, DateTime? time)
        {
            var who = tree.children[0].children[1].children[0].children[0].children[0].text;
            var text = tree.children[0].children[1].children[0].children[1].text;
            return new SubtitleMessage { Who = who, Text = text, Time = time };
        }

        volatile bool updating = false;
        void OnTimer(object? state)
        {
            if (updating) return;
            updating = true;
            UpdateMessage();
            updating = false;
            //this.Dispatcher.BeginInvoke(UpdateLines);
        }

        //private void UpdateLines()
        //{
        //    lines.Clear();
        //    foreach (var msg in messageList)
        //    {
        //        lines.Add($"{msg.Who}: {msg.Text}");
        //        if (!string.IsNullOrEmpty(msg.ZH))
        //            lines.Add($"      中文: {msg.ZH}");
        //        if (!string.IsNullOrEmpty(msg.EN))
        //            lines.Add($"      英文: {msg.EN}");
        //        if (!string.IsNullOrEmpty(msg.JA))
        //            lines.Add($"      日文: {msg.JA}");
        //    }
        //}

        bool once = false;
        void UpdateMessage()
        {
            // if (once) return;
            once = true;
            try
            {
                var count = targetAccRoot.accChildCount;
                object[] arry = new object[count + 1];
                var start = Math.Max(0, count - 20);
                if (Succeeded(AccessibleChildren(targetAccRoot, start, arry, out var len)))
                {
                    var msgs = new List<SubtitleMessage>();
                    int last_match = -1, matchcount = 0;
                    for (int c = len - 1; c > 0; c--)
                    {
                        if (arry[c] is IAccessible accCh)
                        {
                            var tree = DumpTree(accCh, start + c, 1);
                            if (!Check(tree)) continue;
                            var msg = TreeToMessage(tree, DateTime.Now);
                            msgs.Add(msg);

                            var startIndex = matchcount > 0 ? last_match - matchcount : messageList.Count - 1;
                            //Debug.WriteLine($"Finding from {startIndex} for {msg.Text}");
                            var found = messageList.List.FindLastIndex(startIndex, m => m.Who == msg.Who && m.Text == msg.Text);
                            //Debug.WriteLine($"Find at [{found}] of {msg.Text}");
                            if (found != -1) // text matched
                            {
                                if (last_match == -1) // found last match
                                {
                                    last_match = found;
                                    matchcount = 1;
                                }
                                else if (found == last_match - matchcount) // continued
                                {
                                    matchcount += 1;
                                }
                                else // broke
                                {
                                    last_match = found;
                                    matchcount = 1;
                                }
                            }
                            else // new text
                            {
                                last_match = -1;
                                matchcount = 0;
                            }
                            if (matchcount >= 3) break; // limit to 3
                        }
                    }
                    //Debug.WriteLine($"Last match at [{last_match}] {matchcount} found.");

                    msgs.RemoveRange(msgs.Count - matchcount, matchcount);
                    msgs.Reverse();
                    foreach (var msg in msgs)
                    {
                        Debug.WriteLine($"enqueue {msg.Text}");
                        if (SEPARATE)
                        {
                            for (int langid = 1; langid <= 3; langid++)
                            {
                                var lang = (LangID)langid;
                                if (lang == DataModel.LangID)
                                {
                                    msg.MakeCTS(this.cts.Token);
                                    RtStack(lang).Push(msg);
                                }
                                else
                                    Stack(lang).Push(msg);
                            }
                        }
                        else
                        {
                            msg.MakeCTS(this.cts.Token);
                            rtstack.Push(msg);
                        }
                    }
                    Dispatcher.BeginInvoke(() =>
                    {
                        var list = messageList.List;
                        var first_replace = last_match + 1;
                        var replace_n = list.Count - first_replace;
                        for (int i = 0; i < replace_n; i++)
                        {
                            var old = messageList[first_replace + i];
                            messageList[first_replace + i] = msgs[i];
                            old.Text = null; // mark as discarded
                            old.Cancel();
                        }
                        for (int i = replace_n; i < msgs.Count; i++)
                            messageList.Add(msgs[i]);

                        if (FollowLast)
                        {
                            var lvap = new ListViewAutomationPeer(this.lbMessage);
                            var svap = lvap.GetPattern(PatternInterface.Scroll) as ScrollViewerAutomationPeer;
                            var scroll = svap.Owner as ScrollViewer;
                            scroll.ScrollToEnd();
                        }
                    });
                    #region old
                    //int lastfound = -1;
                    //for (int c = 0; c < len; c++)
                    //{
                    //    var child = arry[c];
                    //    if (arry[c] is IAccessible accCh)
                    //    {
                    //        var tree = DumpTree(accCh, start + c, 1);
                    //        if (!Check(tree)) continue;
                    //        var msg = TreeToMessage(tree, DateTime.Now);
                    //        var found = messageList.List.FindLastIndex(m => m.Who == msg.Who && m.Text == msg.Text);
                    //        if (found != -1)
                    //        {
                    //            lastfound = found; continue;
                    //        }
                    //        else
                    //        {
                    //            //lastfound += 1;
                    //            if (lastfound == -1 || lastfound == messageList.Count - 1)
                    //            {
                    //                found = messageList.Count;
                    //                Dispatcher.BeginInvoke(() =>
                    //                {
                    //                    messageList.Add(msg);
                    //                    queue.Enqueue(msg);
                    //                    if (FollowLast)
                    //                    {
                    //                        var lvap = new ListViewAutomationPeer(this.lbMessage);
                    //                        var svap = lvap.GetPattern(PatternInterface.Scroll) as ScrollViewerAutomationPeer;
                    //                        var scroll = svap.Owner as ScrollViewer;
                    //                        scroll.ScrollToEnd();
                    //                    }

                    //                });
                    //            }
                    //            else
                    //            {
                    //                found = lastfound + 1;
                    //                Dispatcher.BeginInvoke(() =>
                    //                {
                    //                    messageList[found] = msg;
                    //                    queue.Enqueue(msg);
                    //                    //messageList.Add(msg);
                    //                    if (FollowLast)
                    //                    {
                    //                        var lvap = new ListViewAutomationPeer(this.lbMessage);
                    //                        var svap = lvap.GetPattern(PatternInterface.Scroll) as ScrollViewerAutomationPeer;
                    //                        var scroll = svap.Owner as ScrollViewer;
                    //                        scroll.ScrollToEnd();
                    //                    }
                    //                });
                    //            }
                    //        }
                    //        lastfound = found;
                    //    }
                    //    else
                    //    {
                    //        //children[c] = new TreePart { id = c, nest = nest + 1, text = new string(acc.get_accName(c).AsSpan()) };
                    //    }
                    //}
                    #endregion
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Update message failed." + ex);
            }
        }
        public bool FollowLast { get; set; } = true;

        bool Check(TreePart t)
        {
            try {
                if (t.children.Length != 1 || t.children[0].role != Role.li) return false;
                var li = t.children[0];
                if (li.children.Length != 2) return false;
                //var div = li.children[0];
                //if (div.role != Role.div || div.children.Length != 1) return false;
                var div = li.children[1];
                if (div.role != Role.div || div.children.Length != 1) return false;
                var div2 = div.children[0];
                if (div2.role != Role.div || div2.children.Length != 2) return false;
                var div3 = div2.children[0];
                if (div3.role != Role.div || div3.children.Length != 1) return false;
                if (div2.children[1].role != Role.text || div3.children[0].role != Role.text) return false;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private TreePart? FindTarget(TreePart? tree)
        {
            if (tree == null) return null;
            if (tree.role == Role.div)
            {
                if (tree.children.Any(c => c.role == Role.list))
                {
                    var lists = tree.children.Where(r => r.role == Role.list);
                    if (lists.All(r => Check(r)))
                    {
                        return tree;
                    }
                }
            }
            foreach (var child in tree.children)
            {
                var sub = FindTarget(child);
                if (sub != null) return sub;
            }
            return null;
        }
        string GetRT(int roleid)
        {
            char[] arrbuf = new char[100];
            GetRoleText((uint)roleid, new Span<char>(arrbuf));
            var str = new string(arrbuf);
            Debug.WriteLine($"{roleid} - {str}");
            return str;
        }
        private void DumpData(IAccessible pacc, int nest)
        {
            var prefix = new string(' ', nest * 2);
            string text = new string(pacc.get_accName(0).AsSpan());
            var role = pacc.get_accRole(0);
            var roletext = (role is string str) ? str : GetRT((int)role);
            lines.Add(prefix + "Name: " + text + " Role: " + roletext);
            //Debug.WriteLine($"{nest}");

            // process messages;
            //if (stop) break;
            try
            {
                var count = pacc.accChildCount;
                Debug.WriteLine($"nest {nest}, childcount: {count}");
                object[] arry = new object[count + 1];
                if (Succeeded(AccessibleChildren(pacc, 0, arry, out var len)))
                {
                    //var child = pacc.get_accChild(i) as IAccessible;
                    for (int c = 0; c < len; c++)
                    {
                        var child = arry[c];
                        if (arry[c] is IAccessible accCh)
                        {
                            DumpData(accCh, nest + 1);
                        }
                        else
                        {
                            //Debug.WriteLine($"NE Child - {pacc.get_accName(arry[c])}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("failed.");
            }

            //var res = client.CompleteChat(new ChatMessage[]
            //{
            //    ChatMessage.CreateSystemMessage($"你是翻译，如果用户的文字是中文，请将用户输入的文字翻译成英文；否则请翻译成中文。"),
            //    ChatMessage.CreateUserMessage(text),
            //});

            //lines.Add("翻译：" + res.Value.Content[0].Text);
        }

        public enum LangID { ALL, ZH, EN, JA };
        public string[] Langs { get; } = new[] { "中文", "英文", "日文" };
        public string Lang1 { get; set; } = "中文";
        public string Lang2 { get; set; } = "英文";

        public class BindingModel : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler? PropertyChanged;
            public void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
            public bool IsZH { get; set; } = true;
            public bool IsEN { get; set; }
            public bool IsJA { get; set; }
            public LangID LangID { get; internal set; } = LangID.ZH;
        }

        public BindingModel DataModel { get; set; } = new BindingModel();

        async Task TranslateMessageDummy(List<SubtitleMessage> msgs, string prompt, CancellationToken token)
        {
            await Task.Delay(1000);
            foreach (var msg in msgs)
            {
                msg.Translated = true;
                msg.ZH = "假翻译 -- " + msg.Text;
            }
        }
        async Task TranslateMessage(List<SubtitleMessage> msgs, string prompt, CancellationToken token)
        {
            try
            {
                var ctoken = token;
                if (msgs.Count == 1) ctoken = msgs[0].GetCancellationToken(token);
                //DateTime start = DateTime.Now;
                var lines = string.Join('\n', msgs.Select((m, n) => $"[{n}]: {m.Text}"));
                //var prompt = PROMPT.Replace("<<lang1>>", Lang1).Replace("<<lang2>>", Lang2);
#if DUMP_TRANS
                File.AppendAllLines("dumptrans.txt", new string[] { "!!!!!!!!!!!!! 翻译 !!!!!!!!!!!!" });
                File.AppendAllLines("dumptrans.txt", msgs.Select(m => m.Text));
#endif
                if (token.IsCancellationRequested) return;

                var res = await client.CompleteChatAsync([
                    ChatMessage.CreateSystemMessage(prompt),
                    ChatMessage.CreateUserMessage(lines),
                ], new ChatCompletionOptions { Temperature = 0.0f }, ctoken);
                var output = res.Value.Content[0].Text;
                var list = output.Split('\n');

                //Debug.WriteLine(lines);
                //Debug.WriteLine("--^^^^-----vvvvv--");
                //Debug.WriteLine(output);
#if DUMP_TRANS
                File.AppendAllLines("dumptrans.txt", new[] { output });
#endif
                var filtered = new List<string>();
                if (list.FirstOrDefault() == "<think>")
                {
                    list = list.SkipWhile(l => l != "</think>").Skip(1).ToArray();
                }
                //Debug.WriteLine(string.Join("\n", list));

                foreach (var line in list)
                {
                    var m = regex.Match(line);
                    if (m.Success)
                    {
                        var n = Convert.ToInt32(m.Groups[1].Value);
                        var lang = m.Groups[2].Value;
                        var text = m.Groups[3].Value;
                        if (n < 0 || n >= msgs.Count)
                        {
                            Debug.WriteLine("ERROR");
                            continue;
                        }
                        var msg = msgs[n];
                        switch (lang)
                        {
                            case "中": msg.ZH = text; break;
                            case "英": msg.EN = text; break;
                            case "日": msg.JA = text; break;
                        };
                        msg.Translated = true;
                    }
                }
                //Debug.WriteLine(" - 翻译：" + (DateTime.Now - start).TotalSeconds);
            }
            catch (TaskCanceledException ex)
            {
                // ignore
            }
            catch (Exception ex)
            {
#if DUMP_TRANS
                File.AppendAllLines("dumptrans.txt", new[] { "翻译异常", ex.ToString() });
#endif
                Debug.WriteLine(ex.ToString());
            }
        }

        private void DumpChildren(IAccessible pacc, int nest)
        {
            DumpData(pacc, nest);
            //for (var i = 0; i < pacc.accChildCount; i++)
            //{
            //    //var child = pacc.get_accChild(i) as IAccessible;
            //    //if (child != null)
            //     DumpData(pacc, nest, i);
            //}
        }

        //WINEVENTPROC HandleWinEvent = (hWinEventHook, ev, hwnd, idObject, idChild, dwEventThread, dwmsEventTime) =>
        //{
        //};

        public void EndPointer()
        {
            btnFind.IsChecked = false;
        }

        ObservableCollection<string> lines = new ObservableCollection<string>()
        {
        };

        public MainWindow()
        {
            InitializeComponent();

            API_KEY = Properties.Settings.Default.API_KEY;
            API_ENDPOINT = Properties.Settings.Default.API_ENDPOINT;
            MODEL = Properties.Settings.Default.MODEL;
            PROMPT = Properties.Settings.Default.PROMPT;
            PROMPT_ZH = Properties.Settings.Default.PROMPT_ZH;
            PROMPT_EN = Properties.Settings.Default.PROMPT_EN;
            PROMPT_JA = Properties.Settings.Default.PROMPT_JA;
            SEPARATE = Properties.Settings.Default.SEPARATE;
            WORKER_COUNT = Properties.Settings.Default.WORKER_COUNT;
            TRANSLATE_BATCH = Properties.Settings.Default.TRANSLATE_BATCH;

            DataContext = this;

            win = this;
            lbMessage.ItemsSource = lines;
            OpenAIClient client = new OpenAIClient(new ApiKeyCredential(API_KEY), new OpenAIClientOptions { Endpoint = new Uri(API_ENDPOINT) });
            Debug.WriteLine($"{MODEL} | {API_ENDPOINT} | {API_KEY}");
            this.client = client.GetChatClient(MODEL);
            this.regex = new Regex(Properties.Settings.Default.REGEX);
        }

        UnhookWinEventSafeHandle? hook;
        CancellationTokenSource cts = new CancellationTokenSource();
        ConcurrentStack<SubtitleMessage> stack = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> stack_zh = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> stack_en = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> stack_ja = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> rtstack = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> rtstack_zh = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> rtstack_en = new ConcurrentStack<SubtitleMessage>();
        ConcurrentStack<SubtitleMessage> rtstack_ja = new ConcurrentStack<SubtitleMessage>();

        ConcurrentStack<SubtitleMessage> RtStack(LangID langid) => langid switch { LangID.ZH => rtstack_zh, LangID.EN => rtstack_en, LangID.JA => rtstack_ja };
        ConcurrentStack<SubtitleMessage> Stack(LangID langid) => langid switch { LangID.ZH => stack_zh, LangID.EN => stack_en, LangID.JA => stack_ja };

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            flag = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            hook = PInvoke.SetWinEventHook(EVENT_MIN, EVENT_MAX, new NoReleaseSafeHandle(0), HandleWinEvent, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);

            if (SEPARATE)
            {
                for (int langid = 1; langid <= 3; langid ++)
                {
                    var lang = (LangID)langid;
                    var rtstack = RtStack(lang);
                    var stack = Stack(lang);
                    for (int i = 1; i <= WORKER_COUNT; i++)
                        Task.Factory.StartNew((i) => TranslateTaskWorker($"RT-{lang}-{i}", lang, rtstack, TRANSLATE_RT_BATCH), i);
                    Task.Factory.StartNew(() => TranslateTaskWorker($"Slow-{lang}-0", lang, stack, TRANSLATE_BATCH));
                }
            }
            else
            {
                for (int i = 1; i <= WORKER_COUNT; i++)
                    Task.Factory.StartNew((i) => TranslateTaskWorker($"RT-{i}", LangID.ALL, this.rtstack, TRANSLATE_RT_BATCH), i);
                Task.Factory.StartNew(() => TranslateTaskWorker("Slow-0", LangID.ALL, this.stack, TRANSLATE_BATCH));
            }
        }

        async Task TranslateTaskWorker(object taskid, LangID langid, ConcurrentStack<SubtitleMessage> stack, int batch_size)
        {
            Debug.WriteLine($"Worker {taskid} started, at {Thread.CurrentThread.ManagedThreadId}");
            var prompt = langid switch { 0 => PROMPT, LangID.ZH => PROMPT_ZH, LangID.EN => PROMPT_EN, LangID.JA => PROMPT_JA, _ => "" };

            while (!cts.IsCancellationRequested)
            {
                var msgs = new List<SubtitleMessage>();
                while (msgs.Count < batch_size && stack.TryPop(out var msg) && !string.IsNullOrEmpty(msg.Text))
                {
                    if (langid == LangID.ALL || langid == LangID.ZH) msg.ZH = $"翻译中 ({taskid})";
                    if (langid == LangID.ALL || langid == LangID.EN) msg.EN = $"翻译中 ({taskid})";
                    if (langid == LangID.ALL || langid == LangID.JA) msg.JA = $"翻译中 ({taskid})";
                    msg.TranslateTask = taskid.ToString();
                    msgs.Add(msg);
                }

                if (msgs.Count > 0)
                {
                    Debug.WriteLine($"Task {taskid} got {msgs.Count} msgs, from {msgs[0].Text}");

                    DateTime start = DateTime.Now;

                    var task = TranslateMessage(msgs, prompt, cts.Token).ConfigureAwait(true);

                    if (langid == LangID.ALL || langid == DataModel.LangID)
                    {
                        await Dispatcher.BeginInvoke(() =>
                        {
                            foreach (var msg in msgs)
                            {
                                msg.SetText2ByLang(DataModel.LangID);
                            }
                        });
                    }

                    await task;

                    Debug.WriteLine($"{taskid} - 翻译：" + (DateTime.Now - start).TotalSeconds);

                    if (langid == LangID.ALL || langid == DataModel.LangID)
                    {
                        await Dispatcher.BeginInvoke(() =>
                        {
                            var langid = this.DataModel.LangID;
                            foreach (var msg in msgs)
                                msg.SetText2ByLang(langid);
                        });
                    }
                }
                else
                    await Task.Delay(500, cts.Token);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            if (hook != null)
            {
                hook.Close();
            }
        }

        private void ToggleButton_Checked(object sender, RoutedEventArgs e)
        {
            flag = true;
        }

        private void ToggleButton_Unchecked(object sender, RoutedEventArgs e)
        {
            flag = false;
        }

        private void Lang_Click(object sender, RoutedEventArgs e)
        {
            this.DataModel.IsZH = this.rbZH.IsChecked ?? false;
            this.DataModel.IsEN = this.rbEN.IsChecked ?? false;
            this.DataModel.IsJA = this.rbJA.IsChecked ?? false;
            this.DataModel.LangID = DataModel.IsZH ? LangID.ZH : DataModel.IsEN ? LangID.EN : DataModel.IsJA ? LangID.JA : LangID.ALL;
            this.DataModel.OnPropertyChanged("");

            foreach (var msg in this.messageList)
            {
                msg.SetText2ByLang(DataModel.LangID);
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "文本文件|*.txt|JSON 文件|*.json"
            };

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    if (System.IO.Path.GetExtension(dlg.FileName).ToLower() == ".txt")
                    {
                        File.WriteAllLines(dlg.FileName,
                            messageList.SelectMany(m => new[] {
                                $"[{m.Time?.ToString("HH:mm:ss") ?? "时间未知"}]\t- {m.Who }: {m.Text}",
                                "    [中]: " + m.ZH, "",
                                "    [英]: " + m.EN, "",
                                "    [日]: " + m.JA, "",
                            }));
                    }
                    if (System.IO.Path.GetExtension(dlg.FileName).ToLower() == ".json")
                    {
                        var content = JsonSerializer.Serialize(messageList,
                            new JsonSerializerOptions
                            {
                                WriteIndented = true,
                                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                            });
                        File.WriteAllText(dlg.FileName, content);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失败。" + ex.Message);
                }
            }
        }

        private void ListViewItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine(((ListViewItem)sender).Content);
            var msg = ((ListViewItem)sender).Content as SubtitleMessage;
            //msg.Translated = false;
            msg.SetText2("(重新翻译)...");

            if (SEPARATE)
                Stack(DataModel.LangID).Push(msg);
            else
                stack.Push(msg);
        }

        private void lbMessage_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            if (e.VerticalOffset + e.ViewportHeight >= e.ExtentHeight)
            {
                FollowLast = true;
            }
            else
            {
                FollowLast = false;
            }
        }
    }
}